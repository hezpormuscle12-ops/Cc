package com.deskpet.cat;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import rikka.shizuku.Shizuku;

public class MainActivity extends Activity {
    private TextView status;
    private final Handler h = new Handler(Looper.getMainLooper());

    private void addBtn(LinearLayout l, String t, View.OnClickListener c) {
        Button b = new Button(this);
        b.setText(t);
        b.setAllCaps(false);
        b.setOnClickListener(c);
        l.addView(b);
    }

    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        int pad = (int) (20 * getResources().getDisplayMetrics().density);
        l.setPadding(pad, pad * 2, pad, pad);
        status = new TextView(this);
        status.setTextSize(16);
        status.setPadding(0, 0, 0, pad);
        l.addView(status);

        addBtn(l, "1. Cấp quyền hiện trên ứng dụng khác", new View.OnClickListener() {
            @Override public void onClick(View v) {
                startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName())));
            }
        });
        addBtn(l, "2. Cấp quyền Shizuku", new View.OnClickListener() {
            @Override public void onClick(View v) {
                try {
                    if (!Shizuku.pingBinder()) toast("Hãy mở Shizuku và khởi động nó trước");
                    else if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED)
                        Shizuku.requestPermission(100);
                    else toast("Đã cấp rồi");
                } catch (Throwable t) { toast("Chưa có Shizuku"); }
                h.postDelayed(new Runnable() { @Override public void run() { refresh(); } }, 1500);
            }
        });
        addBtn(l, "3. Tắt tối ưu pin (chạy nền ổn định)", new View.OnClickListener() {
            @Override public void onClick(View v) {
                try {
                    startActivity(new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                            Uri.parse("package:" + getPackageName())));
                } catch (Exception e) { toast("Không mở được"); }
            }
        });
        addBtn(l, "4. Bật / tắt mèo", new View.OnClickListener() {
            @Override public void onClick(View v) {
                Intent i = new Intent(MainActivity.this, PetService.class);
                if (PetService.running) stopService(i);
                else if (!Settings.canDrawOverlays(MainActivity.this)) toast("Làm bước 1 trước");
                else if (Build.VERSION.SDK_INT >= 26) startForegroundService(i);
                else startService(i);
                h.postDelayed(new Runnable() { @Override public void run() { refresh(); } }, 500);
            }
        });
        setContentView(l);
        if (Build.VERSION.SDK_INT >= 33)
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 1);
    }

    @Override protected void onResume() { super.onResume(); refresh(); }

    private void refresh() {
        boolean ov = Settings.canDrawOverlays(this);
        boolean sh = false;
        try {
            sh = Shizuku.pingBinder() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED;
        } catch (Throwable ignored) {}
        status.setText("Lớp phủ: " + (ov ? "✅" : "❌")
                + "\nShizuku: " + (sh ? "✅" : "❌")
                + "\nMèo: " + (PetService.running ? "đang chạy" : "đang tắt"));
    }
}

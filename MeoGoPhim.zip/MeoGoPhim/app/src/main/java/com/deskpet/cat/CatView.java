package com.deskpet.cat;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.View;

import java.util.HashSet;
import java.util.Set;

public class CatView extends View {
    private static final int CAT = 0xFF9FD3F0, CAT_L = 0xFFC4E6F8, OUT = 0xFF5A9BC0,
            PINK = 0xFFF7A8B8, DARK = 0xFF22303C;
    // Bàn phím đúng chiều: hàng số ở trên, phím cách ở dưới
    private static final int[][] ROWS = {
            {2, 3, 4, 5, 6, 7, 8, 9, 10, 11},
            {16, 17, 18, 19, 20, 21, 22, 23, 24, 25},
            {30, 31, 32, 33, 34, 35, 36, 37, 38},
            {44, 45, 46, 47, 48, 49, 50},
            {57}};
    private static final float[] ROW_X = {4, 8, 14, 24, 40};
    private static final float[] KEY_W = {17, 17, 17, 17, 100};

    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF r = new RectF();
    private final Set<Integer> keys = new HashSet<>();
    private int mouseBtns;
    private float offX, offY, pawX = 290, pawY = 186, tgtX = 290, tgtY = 186;

    public CatView(Context c) { super(c); }

    private float[] keyRect(int code) {
        for (int i = 0; i < ROWS.length; i++)
            for (int j = 0; j < ROWS[i].length; j++)
                if (ROWS[i][j] == code)
                    return new float[]{190 + ROW_X[i] + j * 19, 209 + i * 16, KEY_W[i], 13};
        return null;
    }

    public void onMove(int dx, int dy) {
        offX = Math.max(-42, Math.min(42, offX + dx * 0.4f));
        offY = Math.max(-16, Math.min(16, offY + dy * 0.4f));
        invalidate();
    }

    public void onKey(int code, boolean down) {
        if (code >= 272 && code <= 274) {
            int bit = 1 << (code - 272);
            if (down) mouseBtns |= bit; else mouseBtns &= ~bit;
        } else if (down) {
            keys.add(code);
            float[] k = keyRect(code);
            if (k == null) k = keyRect(57);
            tgtX = k[0] + k[2] / 2;
            tgtY = k[1] + k[3] / 2;
        } else {
            keys.remove(code);
        }
        invalidate();
    }

    private void fill(int c) { p.setStyle(Paint.Style.FILL); p.setColor(c); }

    private void arm(Canvas cv, float sx, float sy, float ex, float ey, boolean press) {
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeCap(Paint.Cap.ROUND);
        p.setStrokeWidth(32); p.setColor(OUT); cv.drawLine(sx, sy, ex, ey, p);
        p.setStrokeWidth(26); p.setColor(CAT); cv.drawLine(sx, sy, ex, ey, p);
        fill(OUT); cv.drawCircle(ex, ey, 16, p);
        fill(press ? CAT : CAT_L); cv.drawCircle(ex, ey, 13, p);
    }

    @Override
    protected void onDraw(Canvas cv) {
        float s = getWidth() / 400f;
        cv.scale(s, s);

        // vật lý mượt
        offX *= 0.9f; offY *= 0.9f;
        pawX += (tgtX - pawX) * 0.35f;
        pawY += (tgtY - pawY) * 0.35f;
        boolean keyDown = !keys.isEmpty();
        boolean click = mouseBtns != 0;

        // bàn
        fill(0xFFC9A27A); cv.drawRect(0, 225, 400, 300, p);
        fill(0xFFA98558); cv.drawRect(0, 225, 400, 230, p);
        // bàn di chuột
        fill(0xFF3A3F4B); r.set(22, 232, 160, 292); cv.drawRoundRect(r, 8, 8, p);
        // bàn phím
        fill(0xFF2B2F38); r.set(186, 203, 394, 292); cv.drawRoundRect(r, 8, 8, p);
        for (int i = 0; i < ROWS.length; i++)
            for (int j = 0; j < ROWS[i].length; j++) {
                float[] k = keyRect(ROWS[i][j]);
                fill(keys.contains(ROWS[i][j]) ? 0xFFFFD166 : 0xFFE8ECF2);
                r.set(k[0], k[1], k[0] + k[2], k[1] + k[3]);
                cv.drawRoundRect(r, 3, 3, p);
            }
        // chuột
        float mx = 90 + offX, my = 262 + offY;
        fill(0xFFF2F2F2); r.set(mx - 14, my - 19, mx + 14, my + 19); cv.drawRoundRect(r, 12, 12, p);
        if (click) { fill(0xFFFF8FA3); r.set(mx - 14, my - 19, mx, my - 3); cv.drawRoundRect(r, 8, 8, p); }
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(1.5f); p.setColor(0xFF999999);
        cv.drawLine(mx, my - 19, mx, my - 3, p);

        // thân + đuôi tai + đầu
        fill(OUT); cv.drawCircle(200, 185, 64, p);
        fill(CAT); cv.drawCircle(200, 185, 61, p);
        // tai
        fill(OUT); tri(cv, 146, 74, 156, 18, 198, 46);
        tri(cv, 254, 74, 244, 18, 202, 46);
        fill(CAT); tri(cv, 152, 70, 159, 28, 190, 48);
        tri(cv, 248, 70, 241, 28, 210, 48);
        fill(PINK); tri(cv, 160, 60, 162, 38, 178, 50);
        tri(cv, 240, 60, 238, 38, 222, 50);
        // đầu
        fill(OUT); cv.drawCircle(200, 100, 60, p);
        fill(CAT); cv.drawCircle(200, 100, 57, p);
        // mắt nhìn theo chuột
        fill(DARK);
        cv.drawCircle(178 + offX / 10, 98 + offY / 8, 7, p);
        cv.drawCircle(222 + offX / 10, 98 + offY / 8, 7, p);
        fill(0xFFFFFFFF);
        cv.drawCircle(180 + offX / 10, 95 + offY / 8, 2.5f, p);
        cv.drawCircle(224 + offX / 10, 95 + offY / 8, 2.5f, p);
        fill(0x66F7A8B8);
        cv.drawCircle(160, 116, 8, p); cv.drawCircle(240, 116, 8, p);
        fill(PINK); cv.drawCircle(200, 113, 4, p);
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(2); p.setColor(DARK);
        r.set(190, 114, 200, 124); cv.drawArc(r, 0, 180, false, p);
        r.set(200, 114, 210, 124); cv.drawArc(r, 0, 180, false, p);

        // tay trái -> chuột, tay phải -> bàn phím
        arm(cv, 150, 172, mx, my - 2, click);
        arm(cv, 250, 172, pawX, pawY + (keyDown ? 3 : 0), keyDown);

        boolean moving = Math.abs(offX) > 0.05f || Math.abs(offY) > 0.05f
                || Math.abs(tgtX - pawX) > 0.3f || Math.abs(tgtY - pawY) > 0.3f;
        if (moving) postInvalidateOnAnimation();
    }

    private void tri(Canvas cv, float x1, float y1, float x2, float y2, float x3, float y3) {
        android.graphics.Path pa = new android.graphics.Path();
        pa.moveTo(x1, y1); pa.lineTo(x2, y2); pa.lineTo(x3, y3); pa.close();
        cv.drawPath(pa, p);
    }

    @Override
    protected void onMeasure(int w, int h) {
        int width = MeasureSpec.getSize(w);
        setMeasuredDimension(width, width * 3 / 4);
    }
}

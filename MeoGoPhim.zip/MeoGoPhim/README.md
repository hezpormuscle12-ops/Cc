# Mèo Gõ Phím (Bongo Cat cho Android)
Đẩy toàn bộ thư mục này lên GitHub (nhánh main) -> tab Actions -> tải APK ở mục Artifacts.
Cách dùng: mở Shizuku và khởi động -> mở app, làm lần lượt bước 1-4.

package com.cfg.runner

import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewOutlineProvider
import android.widget.*
import rikka.shizuku.Shizuku

class MainActivity : Activity() {
    private lateinit var video: VideoBg
    private lateinit var input: EditText
    private lateinit var log: TextView
    private lateinit var tvShizuku: TextView
    private lateinit var tvSecure: TextView
    private lateinit var tvWrite: TextView
    private lateinit var btnUndo: Button
    private val prefs by lazy { getSharedPreferences("cfg", MODE_PRIVATE) }
    private val myCmd = "adb shell pm grant com.cfg.runner android.permission.WRITE_SECURE_SETTINGS"

    private val binderListener = Shizuku.OnBinderReceivedListener { runOnUiThread { Sh.bind(this); refresh() } }
    private val deadListener = Shizuku.OnBinderDeadListener { Sh.svc = null; runOnUiThread { refresh() } }
    private val permListener = Shizuku.OnRequestPermissionResultListener { _, _ -> runOnUiThread { Sh.bind(this); refresh() } }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(14), dp(12), dp(14), dp(12))
        background = GradientDrawable().apply { setColor(Color.parseColor("#B3101820")); cornerRadius = dp(16).toFloat() }
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) }
    }

    private fun label(t: String, size: Float = 13f, color: Int = Color.WHITE) =
        TextView(this).apply { text = t; textSize = size; setTextColor(color) }

    private fun btn(t: String, weight: Float = 1f, f: () -> Unit) = Button(this).apply {
        text = t; isAllCaps = false; textSize = 13f; setTextColor(Color.WHITE)
        background = GradientDrawable().apply { setColor(Color.parseColor("#CC3D5AFE")); cornerRadius = dp(12).toFloat() }
        setOnClickListener { f() }
        layoutParams = LinearLayout.LayoutParams(0, dp(44), weight).apply { setMargins(dp(3), dp(3), dp(3), dp(3)) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.TRANSPARENT

        val root = FrameLayout(this)
        video = VideoBg(this)
        root.addView(video, FrameLayout.LayoutParams(-1, -1))
        root.addView(View(this).apply { setBackgroundColor(Color.parseColor("#66000000")) }, FrameLayout.LayoutParams(-1, -1))

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(40), dp(14), dp(24))
        }

        // Header: avatar + tên
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val av = ImageView(this).apply {
            setImageResource(R.drawable.avatar)
            scaleType = ImageView.ScaleType.CENTER_CROP
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(v: View, o: Outline) { o.setOval(0, 0, v.width, v.height) }
            }
            clipToOutline = true
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setStroke(dp(2), Color.WHITE) }
            layoutParams = LinearLayout.LayoutParams(dp(64), dp(64))
        }
        val names = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, 0, 0) }
        names.addView(label("Cfg Runner", 22f).apply { setTypeface(null, Typeface.BOLD) })
        names.addView(label("Dán cấu hình → Chạy", 13f, Color.parseColor("#CCFFFFFF")))
        head.addView(av); head.addView(names)
        col.addView(head)

        // Quyền
        val perm = card()
        perm.addView(label("Quyền", 15f).apply { setTypeface(null, Typeface.BOLD) })
        tvShizuku = label(""); tvSecure = label(""); tvWrite = label("")
        perm.addView(tvShizuku); perm.addView(tvSecure); perm.addView(tvWrite)
        val pr = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        pr.addView(btn("Shizuku") { onShizuku() })
        pr.addView(btn("Tự cấp quyền") { autoGrant() })
        pr.addView(btn("WRITE_SETTINGS") { openWriteSettings() })
        perm.addView(pr)
        perm.addView(label("Không dùng Shizuku: chạy lệnh ADB 1 lần (chạm để copy)", 12f, Color.parseColor("#B3FFFFFF")).apply {
            setPadding(0, dp(6), 0, 0)
            setOnClickListener { copy(myCmd) }
        })
        col.addView(perm)

        // Soạn cấu hình
        val ed = card()
        ed.addView(label("Cấu hình", 15f).apply { setTypeface(null, Typeface.BOLD) })
        input = EditText(this).apply {
            hint = "[system]\npointer_speed=7\n[global]\nanimator_duration_scale=0.5\n[shell]\nwm density\n[stop]\ncom.example.app"
            setHintTextColor(Color.parseColor("#66FFFFFF"))
            setTextColor(Color.WHITE)
            typeface = Typeface.MONOSPACE; textSize = 13f
            gravity = Gravity.TOP; isSingleLine = false
            setText(prefs.getString("saved", ""))
            minLines = 8; maxLines = 14
        }
        ed.addView(input, LinearLayout.LayoutParams(-1, -2))
        val r1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        r1.addView(btn("▶ Chạy", 1.3f) { run() })
        btnUndo = btn("↩ Hoàn tác") { undo() }
        r1.addView(btnUndo)
        r1.addView(btn("Mẫu") { templates() })
        ed.addView(r1)
        val r2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        r2.addView(btn("Dán") { paste() })
        r2.addView(btn("Mở file") { startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "*/*" }, 1) })
        r2.addView(btn("Lưu") { prefs.edit().putString("saved", input.text.toString()).apply(); toast("Đã lưu") })
        r2.addView(btn("Xoá") { input.setText(""); log.text = "" })
        ed.addView(r2)
        val sw = Switch(this).apply {
            text = "Tự chạy khi mở máy (cần WRITE_SECURE_SETTINGS)"
            setTextColor(Color.WHITE); textSize = 13f
            isChecked = prefs.getBoolean("auto", false)
            setOnCheckedChangeListener { _, on ->
                prefs.edit().putBoolean("auto", on).putString("saved", input.text.toString()).apply()
                toast(if (on) "Bật, đã lưu cấu hình hiện tại" else "Tắt")
            }
        }
        ed.addView(sw)
        col.addView(ed)

        // Log
        val lg = card()
        lg.addView(label("Kết quả", 15f).apply { setTypeface(null, Typeface.BOLD) })
        log = label("", 12f).apply { typeface = Typeface.MONOSPACE; setTextIsSelectable(true) }
        lg.addView(log)
        col.addView(lg)

        root.addView(ScrollView(this).apply { addView(col); isFillViewport = true }, FrameLayout.LayoutParams(-1, -1))
        setContentView(root)

        try {
            Shizuku.addBinderReceivedListenerSticky(binderListener)
            Shizuku.addBinderDeadListener(deadListener)
            Shizuku.addRequestPermissionResultListener(permListener)
        } catch (_: Throwable) {}
        refresh()
    }

    override fun onResume() { super.onResume(); video.resume(); Sh.bind(this); refresh() }
    override fun onPause() { super.onPause(); video.pause() }
    override fun onDestroy() {
        super.onDestroy(); video.release()
        try {
            Shizuku.removeBinderReceivedListener(binderListener)
            Shizuku.removeBinderDeadListener(deadListener)
            Shizuku.removeRequestPermissionResultListener(permListener)
        } catch (_: Throwable) {}
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    private fun copy(s: String) {
        (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("cmd", s))
        toast("Đã copy lệnh")
    }

    private fun refresh() {
        tvShizuku.text = when {
            !Sh.running() -> "❌ Shizuku: chưa chạy (mở app Shizuku và khởi động)"
            !Sh.granted() -> "⚠ Shizuku: đang chạy, chưa cấp quyền cho app"
            Sh.ready() -> "✅ Shizuku: sẵn sàng (shell)"
            else -> "⏳ Shizuku: đang kết nối dịch vụ…"
        }
        tvSecure.text = if (ConfigEngine.hasSecure(this)) "✅ WRITE_SECURE_SETTINGS" else "❌ WRITE_SECURE_SETTINGS"
        val ws = Settings.System.canWrite(this)
        tvWrite.text = if (ws) "✅ WRITE_SETTINGS" else "⚠ WRITE_SETTINGS: chưa cấp (không bắt buộc)"
        btnUndo.isEnabled = ConfigEngine.hasUndo(this)
        btnUndo.alpha = if (btnUndo.isEnabled) 1f else 0.4f
    }

    private fun onShizuku() {
        if (!Sh.running()) {
            val i = packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")
            if (i != null) startActivity(i) else toast("Chưa cài Shizuku")
        } else if (!Sh.granted()) Sh.request(100)
        else { Sh.bind(this); toast("Đã cấp quyền") }
    }

    private fun autoGrant() {
        if (ConfigEngine.hasSecure(this)) { toast("Đã có quyền rồi"); return }
        if (!Sh.ready()) { toast("Cần Shizuku sẵn sàng trước"); return }
        Thread {
            val r = Sh.exec("pm grant $packageName android.permission.WRITE_SECURE_SETTINGS")
            runOnUiThread {
                log.text = if (r != null && r.first == 0) "Đã tự cấp WRITE_SECURE_SETTINGS." else "Cấp quyền lỗi: ${r?.second}"
                refresh()
            }
        }.start()
    }

    private fun openWriteSettings() {
        startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName")))
    }

    private fun paste() {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val t = cm.primaryClip?.getItemAt(0)?.coerceToText(this)?.toString()
        if (!t.isNullOrEmpty()) input.setText(t)
    }

    private fun run() {
        log.text = "Đang chạy…"
        val text = input.text.toString()
        Thread {
            val r = ConfigEngine.execute(this, text)
            runOnUiThread { log.text = r.log; refresh() }
        }.start()
    }

    private fun undo() {
        Thread {
            val s = ConfigEngine.undo(this)
            runOnUiThread { log.text = s; refresh() }
        }.start()
    }

    private fun templates() {
        val items = arrayOf(
            "Tắt animation" to "[global]\nwindow_animation_scale=0\ntransition_animation_scale=0\nanimator_duration_scale=0",
            "Animation nhanh 0.5x" to "[global]\nwindow_animation_scale=0.5\ntransition_animation_scale=0.5\nanimator_duration_scale=0.5",
            "Con trỏ chuột nhanh nhất" to "[system]\npointer_speed=7",
            "Nhấn giữ nhanh" to "[secure]\nlong_press_timeout=250",
            "Hiện chạm + toạ độ" to "[system]\nshow_touches=1\npointer_location=1",
            "Ép tần số quét 120Hz (tuỳ máy)" to "[system]\nmin_refresh_rate=120.0\npeak_refresh_rate=120.0",
            "Dừng app nền (cần Shizuku)" to "[stop]\ncom.facebook.katana\ncom.zhiliaoapp.musically",
            "Lệnh shell (cần Shizuku)" to "[shell]\nwm size\nwm density"
        )
        AlertDialog.Builder(this).setTitle("Chèn mẫu")
            .setItems(items.map { it.first }.toTypedArray()) { _, i ->
                val cur = input.text.toString()
                input.setText(if (cur.isBlank()) items[i].second else cur.trimEnd() + "\n" + items[i].second)
            }.show()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val uri = data?.data ?: return
        if (requestCode == 1 && resultCode == RESULT_OK) {
            try { input.setText(contentResolver.openInputStream(uri)!!.bufferedReader().readText()) }
            catch (e: Exception) { log.text = "Lỗi đọc file: ${e.message}" }
        }
    }
}

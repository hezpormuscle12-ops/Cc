package com.cfg.runner

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Mở máy xong tự chạy cấu hình đã lưu (chỉ phần global/system/secure, cần quyền WRITE_SECURE_SETTINGS). */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        val p = ctx.getSharedPreferences("cfg", Context.MODE_PRIVATE)
        if (!p.getBoolean("auto", false)) return
        val text = p.getString("saved", "") ?: return
        if (text.isBlank() || !ConfigEngine.hasSecure(ctx)) return
        // chỉ giữ section settings, vì shell/stop cần Shizuku mà lúc mới mở máy chưa chắc chạy
        val keep = StringBuilder()
        var ok = false
        for (l in text.lines()) {
            val t = l.trim()
            if (t.startsWith("[") && t.endsWith("]")) ok = t.trim('[', ']').trim().lowercase() in setOf("global", "system", "secure")
            if (ok || (t.startsWith("[") && ok)) keep.append(l).append('\n')
        }
        ConfigEngine.execute(ctx, keep.toString(), record = false)
    }
}

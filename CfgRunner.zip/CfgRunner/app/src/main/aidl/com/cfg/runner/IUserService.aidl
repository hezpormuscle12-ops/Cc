package com.cfg.runner;

interface IUserService {
    void destroy() = 16777114;
    String exec(String cmd) = 1;
}
